#!/usr/bin/env bash
# Author: Benjamin T. James
# If you want data to not be re-downloaded, make DATA_DIR beforehand and populate with those files
source /broad/compbio/cboix/ENCODE_DATA/bin/config_ChromImpute.sh

# Arguments:
SRC_DIR="$BINDIR/eglinking/src"
MASTERLIST_TXT="${DMLPREF}_hg19.core.srt.txt"
MA_MATRICES="$DBDIR/markassay_matrices/"
ENH_INDICES="$DBDIR/ENH_masterlist_indices_ind.cp.gz" # must be present somewhere

# Directories for linking:
DATA_DIR="$DBDIR/linking_data";
SAMPLE_DIR="$DATA_DIR/sample";

function die() { echo "$*" 1>&2; exit 1; }

[[ $- == *i* ]] || die "Not an interactive shell, rerun with bash -i"
test -d $MA_MATRICES || die "markassay_matrices dir $MA_MATRICES not found";
test -f $MASTERLIST_TXT || die "masterlist.txt must exist ($MASTERLIST_TXT)";
test -f $ENH_INDICES || die "ENH indices must exist ($ENH_INDICES)";
test -d $SRC_DIR || die "Source dir $SRC_DIR must exist and have all Python files";

# Create the appropriate conda environment:
export PATH="$SRC_DIR:$PATH";
if [[ "$( conda info --envs | grep -c "linking" )" == "0" ]]; then
    yes | conda create -n linking -c conda-forge scikit-learn numpy scipy requests wget gawk coreutils
fi
conda activate linking

mkdir -p $DATA_DIR $DATA_DIR/out
cd $DATA_DIR

function download { # sees if file exists before downloading
    basename $1 | xargs test -f && echo "$( basename $1) already exists" || wget $1;
}

cp $DBDIR/public_intermediate_data_released/rnaseq_data/merged_log2fpkm.pc.mtx.gz ${DATA_DIR}
# cp $DBDIR/public_intermediate_data_released/enhancers_data/Enhancer_matrix_names.txt ${DATA_DIR} # Don't actually need anything from enh (just ind)
download 'ftp://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_33/GRCh37_mapping/gencode.v33lift37.annotation.gtf.gz'
download 'https://hgdownload.soe.ucsc.edu/goldenPath/hg19/bigZips/hg19.chrom.sizes'

# DNase-seq non-binary matrix:
# cp ${IMPUTED_DIR}/D*/*allchr*.cp.gz $MA_MATRICES
# cp ${IMPUTED_DIR}/D*/*allchr*.cp.gz $DATA_DIR

# Turn the compressed files into MTX (submit to queue):
# TODO: Not H3K4me2
for file in `ls $MA_MATRICES/*r25_e100*merged*_csr.cp.gz`; do
    base=$( basename $file )
    attrfile=${file%_csr.*}_attr.cp.gz
    mtfile=${base%_csr.*}.mtx
    if [[ ! -f $DATA_DIR/$base ]]; then
        cp $file $DATA_DIR
        cp $attrfile $DATA_DIR
    fi
    if [[ ! -f ${mtfile}.gz ]] || [[ $file -nt ${mtfile}.gz ]]; then
        echo "Creating ${mtfile}.gz"
        qsub -cwd -P compbio_lab -l h_vmem=15G -l h_rt=0:30:00 -N process_markmat -j y -b y -V -r y -o $DATA_DIR/out "$SRC_DIR/save_mtx.py $file; gzip $mtfile"
    fi
done

rm H3K4me2_all*.gz

marks=($PWD/*merged.mtx.gz);
cpmarks=($PWD/*merged_csr.cp.gz);

# -------------------------------------
# Run next three processes concurrently
# Processing steps to prep annotations:
# -------------------------------------
# Assume H3K27ac has same sample list as other marks
test -f tss.txt || ${SRC_DIR}/get_tss.py "$DATA_DIR/gencode.v33lift37.annotation.gtf.gz" "merged_log2fpkm.pc.mtx.gz" > tss.txt &

mkdir -p $SAMPLE_DIR && cd $SAMPLE_DIR

if [[ ! -f shared_samples.txt ]]; then
    nl "$DATA_DIR/mark_matrix_names.txt" > mark_mat_names_numbered # cannot use BASH process substitution because needs to be re-read
    zcat "$DATA_DIR/merged_log2fpkm.pc.mtx.gz" | awk '/^BSS/ { print $1 }' | sort | uniq > $SAMPLE_DIR/rnaseq_samples.txt
    cat $SAMPLE_DIR/rnaseq_samples.txt | xargs -I@ -P0 grep @ mark_mat_names_numbered | awk '{ print $2 " " $1 }' > $SAMPLE_DIR/shared_samples.txt &
fi

test -f $SAMPLE_DIR/masterlist.bed || get_masterlist.py $ENH_INDICES < $MASTERLIST_TXT > $SAMPLE_DIR/masterlist.bed &
wait;
rm mark_mat_names_numbered

# ---------------------------
# Make all enhancer data dirs
# ---------------------------
< "$DATA_DIR/mark_matrix_names.txt" xargs -n1 mkdir

mkdir -p spt
split -l 10 shared_samples.txt 'spt/x' # creates spt/xaa spt/xab ..

# Generates sample sub-dirs and rna.txt files
for file in `find spt -type f`; do
    echo "Submitting RNA and marks for chunk: $file"
    qsub -cwd -P compbio_lab -l h_vmem=15G -l h_rt=04:00:00 -N chunk_rnadata -j y -b y -V -r y -o $DATA_DIR/out "${SRC_DIR}/sample_rna_grep.py $file $DATA_DIR/merged_log2fpkm.pc.mtx.gz"
    # qsub -cwd -P compbio_lab -l h_vmem=15G -l h_rt=04:00:00 -hold_jid process_markmat -N chunk_markdata -j y -b y -V -r y -o $DATA_DIR/out "${SRC_DIR}/sample_mark_grep.py $file masterlist.bed ${cpmarks[@]}" # OLD FOR ALL MARKS
    # Run per-mark jobs:
    for markfile in `ls $DATA_DIR/*merged_csr.cp.gz`; do
        echo $markfile
        qsub -cwd -P compbio_lab -l h_vmem=15G -l h_rt=01:00:00 -hold_jid process_markmat -N chunk_markdata -j y -b y -V -r y -o $DATA_DIR/out "${SRC_DIR}/sample_mark_grep.py $file masterlist.bed $markfile"
    done
done

# rm spt/x*
# rmdir spt

# Generates E7.bed, E8.bed, etc files
cd $SAMPLE_DIR
< "$DATA_DIR/mark_matrix_names.txt" get_all_enhancer_regions.py E7 E8 E9 E10 E11 E15

